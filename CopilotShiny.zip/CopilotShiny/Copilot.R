packages <- c("shiny", "readr", "readxl", "dplyr", "reshape2", 
              "ggplot2", "stringr", "plotly", "tidyverse", 
              "gprofiler2", "corrplot", "pheatmap", "reticulate", "ggeasy",
              "zip", "DT")

for (pkg in packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

library(shiny)
setwd("C:/Users/jonas/OneDrive/Desktop/Vis_phos/CopilotShiny4")
runApp()

#setwd("C:/Users/jonas/OneDrive/Desktop/Vis_phos/Copilot Shiny2")
#shinylive::export(appdir = "web app", destdir = "docs")
#httpuv::runStaticServer("docs/", port=8008)
